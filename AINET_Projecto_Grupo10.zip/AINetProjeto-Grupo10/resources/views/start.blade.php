<!DOCTYPE html>
<html>
<head>
    <title>Imagine Shirt</title>
    <link rel="stylesheet" type="text/css" href="../css/start.css">
</head>
<body>
    <h1>Imagine Shirt</h1>
    <div id="header">
        <h2>Projeto AINET - ImagineShirt</h2>
    </div>
    <div id="students">
        <h3>Alunos:</h3>
        <table>
            <tr>
                <th>Nome</th>
                <th>Número</th>
            </tr>
            <tr>
                <td>João Pedro Da Rocha Valverde Martins</td>
                <td>2182185</td>
            </tr>
            <tr>
                <td>Daniel Marques Gonçalves</td>
                <td>2201790</td>
            </tr>
            <tr>
                <td>Tiago José Figueira Pires Rodrigues dos Reis</td>
                <td>2201793</td>
            </tr>
        </table>
    </div>
    <a id="login-btn" href="/login">Login</a>
    <a id="register-btn" href="/register">Registo</a>
</body>
</html>
